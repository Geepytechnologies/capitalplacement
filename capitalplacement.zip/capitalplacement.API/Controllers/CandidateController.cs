﻿using capitalplacement.API.DTOs;
using capitalplacement.Application.DTOs;
using capitalplacement.Application.services;
using capitalplacement.Domain.Entities;
using capitalplacement.Domain.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace capitalplacement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private readonly ICosmosdbService<Candidate> _cosmosdbService;
        public CandidateController(ICosmosdbService<Candidate> cosmosdbService)
        {
            _cosmosdbService = cosmosdbService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCandidate(string id)
        {
            return Ok(await _cosmosdbService.GetItemAsync(id));
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateCandidate([FromBody] Candidate candidate)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                candidate.Id = Guid.NewGuid().ToString();
                

                await _cosmosdbService.AddItemAsync(candidate);
                return CreatedAtAction(nameof(GetCandidate), new { id = candidate.Id }, candidate);

                

            }
            catch (Exception ex)
            {

                var errorResponse = new ErrorResponseDto
                {
                    StatusCode = 500,
                    Message = "Internal Server Error: " + ex.Message
                };

                return StatusCode(500, errorResponse);
            }
        }

        // GET api/items
        [HttpGet]
        public async Task<IActionResult> List()
        {
            return Ok(await _cosmosdbService.GetItemsAsync("SELECT * FROM c"));
        }
    }
}
