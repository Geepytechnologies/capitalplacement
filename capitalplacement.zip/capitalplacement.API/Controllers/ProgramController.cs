﻿using capitalplacement.API.DTOs;
using capitalplacement.Domain.Entities;
using capitalplacement.Domain.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace capitalplacement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProgramController: ControllerBase
    {
        private readonly ICosmosdbService<ProgramDetails> _cosmosdbService;
        public ProgramController(ICosmosdbService<ProgramDetails> cosmosdbService)
        {
            _cosmosdbService = cosmosdbService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProgram(string id)
        {
            return Ok(await _cosmosdbService.GetItemAsync(id));
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateProgram([FromBody] ProgramDetails program)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                program.Id = Guid.NewGuid().ToString();


                await _cosmosdbService.AddItemAsync(program);
                return CreatedAtAction(nameof(GetProgram), new { id = program.Id }, program);



            }
            catch (Exception ex)
            {

                var errorResponse = new ErrorResponseDto
                {
                    StatusCode = 500,
                    Message = "Internal Server Error: " + ex.Message
                };

                return StatusCode(500, errorResponse);
            }
        }

        // GET api/items
        [HttpGet]
        public async Task<IActionResult> List()
        {
            return Ok(await _cosmosdbService.GetItemsAsync("SELECT * FROM c"));
        }

        // update api/item
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] ProgramDetails program)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var existingProgram = await _cosmosdbService.GetItemAsync(id);
            if (existingProgram == null)
            {
                return NotFound();
            }
            await _cosmosdbService.UpdateItemAsync(id, program);
            return Ok();
        }
    }

}
