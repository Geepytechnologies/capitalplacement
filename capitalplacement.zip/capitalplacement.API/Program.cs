using capitalplacement.Infrastructure;
using capitalplacement.Application;
using capitalplacement.Application.services;
using capitalplacement.Domain.Repositories;
using System.Configuration;
using capitalplacement.Domain.Entities;
using static System.Net.Mime.MediaTypeNames;

static async Task<Dictionary<string, ICosmosdbService<T>>> InitializeCosmosClient<T>(IConfiguration configuration) where T : class
{
    string cosmosDbAccount = Environment.GetEnvironmentVariable("COSMOSDB_ACCOUNT");
    string cosmosDbKey = Environment.GetEnvironmentVariable("COSMOSDB_KEY");
    string cosmosDbDatabase = Environment.GetEnvironmentVariable("COSMOSDB_DATABASE");
    string cosmosDbContainer = Environment.GetEnvironmentVariable("COSMOSDB_CONTAINER");
    Console.WriteLine(cosmosDbAccount);

    //var databaseName = "Geepy";
    var containername = configuration["ContainerName"];
 
    var client = new Microsoft.Azure.Cosmos.CosmosClient(cosmosDbAccount, cosmosDbKey);
    var database = await client.CreateDatabaseIfNotExistsAsync(cosmosDbDatabase);

    // Define the container names
    var containerNames = new List<string> { "Candidates", "Program" };

    // Dictionary to hold the initialized services
    var services = new Dictionary<string, ICosmosdbService<T>>();

    // Create containers and initialize services
    foreach (var containerName in containerNames)
    {
        await database.Database.CreateContainerIfNotExistsAsync(containerName, "/id");
        var cosmosDbService = new CosmosdbService<T>(client, cosmosDbDatabase, containerName);
        services.Add(containerName, cosmosDbService);
    }
   
    return services;
}

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddApplicationServices();

var candidateServices = InitializeCosmosClient<Candidate>(builder.Configuration.GetSection("CosmosDb")).GetAwaiter().GetResult();
var programServices = InitializeCosmosClient<ProgramDetails>(builder.Configuration.GetSection("CosmosDb")).GetAwaiter().GetResult();

builder.Services.AddSingleton(candidateServices["Candidates"]);
builder.Services.AddSingleton(programServices["Program"]);


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
