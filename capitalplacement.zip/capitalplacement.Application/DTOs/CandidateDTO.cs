﻿using capitalplacement.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capitalplacement.Application.DTOs
{
    public class CandidateDTO
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string Nationality { get; set; }

        public string CurrentResidence { get; set; }

        public string Idnumber { get; set; }

        public DateOnly DateOfBirth { get; set; }

        public Gender Gender { get; set; }

        public string AboutYourself { get; set; }

        public string YearOfGraduation { get; set; }

        public string[] Multiplechoice { get; set; }

        public string RejectedByUkEmbassy { get; set; }

        public int YearsOfExperience { get; set; }

        public DateOnly DateMovedToUk { get; set; }
    }
}
