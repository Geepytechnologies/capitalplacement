﻿using capitalplacement.Domain.Entities;
using capitalplacement.Domain.Repositories;
using Microsoft.Azure.Cosmos;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Container = Microsoft.Azure.Cosmos.Container;

namespace capitalplacement.Application.services
{
    public class CosmosdbService<T>: ICosmosdbService<T> where T : class
    {
        private readonly Container _container;

        public CosmosdbService(CosmosClient cosmosClient, string databaseName, string containerName)
        {
            _container = cosmosClient.GetContainer(databaseName, containerName);
        }
        public async Task<T> GetItemAsync(string id)
        {
            try
            {
                ItemResponse<T> response = await _container.ReadItemAsync<T>(id, new PartitionKey(id));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
        }
        public async Task<IEnumerable<T>> GetItemsAsync(string queryString)
        {
            var query = _container.GetItemQueryIterator<T>(new QueryDefinition(queryString));
            List<T> results = new List<T>();
            while (query.HasMoreResults)
            {
                FeedResponse<T> response = await query.ReadNextAsync();
                results.AddRange(response.ToList());
            }
            return results;
        }
        public async Task AddItemAsync(T item)
        {
            await _container.CreateItemAsync(item, new PartitionKey(item.GetType().GetProperty("Id").GetValue(item, null).ToString()));
        }

        public async Task<T> UpdateItemAsync(string id, T item)
        {
            ItemResponse<T> response = await _container.UpsertItemAsync(item, new PartitionKey(id));
            return response.Resource;
        }

        public async Task DeleteItemAsync(string id)
        {
            await _container.DeleteItemAsync<T>(id, new PartitionKey(id));
        }
    }
}
